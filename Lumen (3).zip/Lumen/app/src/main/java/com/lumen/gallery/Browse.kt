package com.lumen.gallery

import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil3.compose.AsyncImage
import coil3.request.ImageRequest
import coil3.request.crossfade

private class ViewerRequest(val items: List<MediaItem>, val index: Int)

// ───────────────────────── Root ─────────────────────────

@Composable
fun LumenApp(vm: GalleryViewModel) {
    val media by vm.media.collectAsStateWithLifecycle()
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var albumId by rememberSaveable { mutableStateOf<Long?>(null) }
    var req by remember { mutableStateOf<ViewerRequest?>(null) }
    var visible by remember { mutableStateOf(false) }

    val photosState = rememberLazyGridState()
    val albumsState = rememberLazyGridState()
    val detailState = rememberLazyGridState()
    val albums = remember(media) { buildAlbums(media) }
    val c = LocalLumen.current

    LaunchedEffect(albumId) { detailState.scrollToItem(0) }
    BackHandler(enabled = albumId != null && !visible) { albumId = null }

    val open: (List<MediaItem>, Int) -> Unit = { l, i -> req = ViewerRequest(l, i); visible = true }

    Box(Modifier.fillMaxSize().background(c.bg)) {
        when {
            albumId != null -> {
                val a = albums.firstOrNull { it.id == albumId }
                MediaGrid(
                    title = a?.name ?: "", subtitle = "${a?.items?.size ?: 0} items",
                    list = a?.items.orEmpty(), state = detailState,
                    onBack = { albumId = null },
                    onOpen = { i -> open(a?.items.orEmpty(), i) },
                )
            }
            tab == 0 -> MediaGrid(
                title = "Library", subtitle = "${media.size} photos & videos",
                list = media, state = photosState, onBack = null,
                onOpen = { i -> open(media, i) },
            )
            else -> AlbumsScreen(albums, albumsState) { albumId = it }
        }
        if (albumId == null) {
            FloatingBar(tab, { tab = it }, Modifier.align(Alignment.BottomCenter))
        }
        AnimatedVisibility(
            visible = visible,
            enter = fadeIn(tween(220)) + scaleIn(tween(260), initialScale = 0.92f),
            exit = fadeOut(tween(180)) + scaleOut(tween(220), targetScale = 0.92f),
        ) {
            val r = req
            if (r != null) {
                Viewer(
                    items = r.items, startIndex = r.index,
                    onClose = { visible = false },
                    onDeleted = { visible = false; vm.refresh() },
                )
            }
        }
    }
}

// ───────────────────────── Shared helpers ─────────────────────────

@Composable
fun Pic(item: MediaItem, modifier: Modifier, scale: ContentScale = ContentScale.Crop) {
    val ctx = LocalContext.current
    AsyncImage(
        model = remember(item.uri) { ImageRequest.Builder(ctx).data(item.uri).crossfade(160).build() },
        contentDescription = null,
        contentScale = scale,
        modifier = modifier,
    )
}

@Composable
fun LargeTitle(title: String, subtitle: String, onBack: (() -> Unit)?) {
    val c = LocalLumen.current
    Column(Modifier.padding(horizontal = 16.dp).padding(top = 12.dp, bottom = 6.dp)) {
        if (onBack != null) {
            Row(Modifier.pressable(onBack).padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.ArrowBackIosNew, null, tint = c.accent, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
                Text("Albums", color = c.accent, fontSize = 17.sp)
            }
        }
        Text(title, fontSize = 34.sp, fontWeight = FontWeight.Bold, color = c.text, letterSpacing = (-0.5).sp)
        Text(subtitle, fontSize = 14.sp, color = c.secondary)
    }
}

// ───────────────────────── Photos grid ─────────────────────────

private sealed interface Entry {
    data class Header(val label: String) : Entry
    data class Cell(val item: MediaItem, val index: Int) : Entry
}

private fun buildEntries(items: List<MediaItem>): List<Entry> {
    val out = ArrayList<Entry>(items.size + 64)
    var last = ""
    items.forEachIndexed { i, m ->
        val label = dayLabel(m.takenAt)
        if (label != last) { out += Entry.Header(label); last = label }
        out += Entry.Cell(m, i)
    }
    return out
}

@Composable
fun MediaGrid(
    title: String,
    subtitle: String,
    list: List<MediaItem>,
    state: LazyGridState,
    onBack: (() -> Unit)?,
    onOpen: (Int) -> Unit,
) {
    val c = LocalLumen.current
    val entries = remember(list) { buildEntries(list) }
    LazyVerticalGrid(
        columns = GridCells.Fixed(4),
        state = state,
        modifier = Modifier.fillMaxSize().background(c.bg),
        horizontalArrangement = Arrangement.spacedBy(1.5.dp),
        verticalArrangement = Arrangement.spacedBy(1.5.dp),
        contentPadding = PaddingValues(
            top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding(),
            bottom = 120.dp,
        ),
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) { LargeTitle(title, subtitle, onBack) }
        items(
            items = entries,
            key = { e ->
                when (e) {
                    is Entry.Header -> "h-${e.label}"
                    is Entry.Cell -> "m-${e.item.id}"
                }
            },
            span = { e -> GridItemSpan(if (e is Entry.Header) maxLineSpan else 1) },
            contentType = { it::class },
        ) { e ->
            when (e) {
                is Entry.Header -> Text(
                    e.label, color = c.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(start = 16.dp, top = 18.dp, bottom = 8.dp),
                )
                is Entry.Cell -> Thumb(e.item, { onOpen(e.index) })
            }
        }
    }
}

@Composable
private fun Thumb(item: MediaItem, onClick: () -> Unit) {
    val c = LocalLumen.current
    Box(Modifier.aspectRatio(1f).pressable(onClick).background(c.surface)) {
        Pic(item, Modifier.fillMaxSize())
        if (item.isVideo) {
            Text(
                durationLabel(item.durationMs), color = Color.White, fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.align(Alignment.BottomEnd).padding(5.dp)
                    .clip(RoundedCornerShape(50)).background(Color.Black.copy(alpha = 0.45f))
                    .padding(horizontal = 6.dp, vertical = 2.dp),
            )
        }
    }
}

// ───────────────────────── Albums ─────────────────────────

@Composable
private fun AlbumsScreen(albums: List<Album>, state: LazyGridState, onOpen: (Long) -> Unit) {
    val c = LocalLumen.current
    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        state = state,
        modifier = Modifier.fillMaxSize().background(c.bg),
        horizontalArrangement = Arrangement.spacedBy(14.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp),
        contentPadding = PaddingValues(
            start = 16.dp, end = 16.dp,
            top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding(),
            bottom = 120.dp,
        ),
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            Column(Modifier.padding(top = 12.dp, bottom = 6.dp)) {
                Text("Albums", fontSize = 34.sp, fontWeight = FontWeight.Bold, color = c.text, letterSpacing = (-0.5).sp)
                Text("${albums.size} albums", fontSize = 14.sp, color = c.secondary)
            }
        }
        items(albums, key = { it.id }) { a ->
            Column(Modifier.pressable { onOpen(a.id) }) {
                Box(Modifier.aspectRatio(1f).clip(RoundedCornerShape(22.dp)).background(c.surface)) {
                    Pic(a.items.first(), Modifier.fillMaxSize())
                }
                Spacer(Modifier.height(8.dp))
                Text(a.name, color = c.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1,
                    modifier = Modifier.padding(horizontal = 4.dp))
                Text("${a.items.size}", color = c.secondary, fontSize = 13.sp,
                    modifier = Modifier.padding(horizontal = 4.dp))
            }
        }
    }
}

// ───────────────────────── Floating tab bar ─────────────────────────

@Composable
private fun FloatingBar(tab: Int, onTab: (Int) -> Unit, modifier: Modifier) {
    val c = LocalLumen.current
    Row(
        modifier
            .navigationBarsPadding()
            .padding(bottom = 14.dp)
            .shadow(18.dp, CircleShape, ambientColor = Color.Black.copy(0.25f), spotColor = Color.Black.copy(0.25f))
            .clip(CircleShape)
            .background(c.bar)
            .padding(5.dp),
    ) {
        BarItem(Icons.Rounded.PhotoLibrary, "Photos", tab == 0) { onTab(0) }
        BarItem(Icons.Rounded.Collections, "Albums", tab == 1) { onTab(1) }
    }
}

@Composable
private fun BarItem(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, selected: Boolean, onClick: () -> Unit) {
    val c = LocalLumen.current
    val bg by androidx.compose.animation.animateColorAsState(
        if (selected) c.accent.copy(alpha = 0.15f) else Color.Transparent, tween(220), label = "bg",
    )
    val fg by androidx.compose.animation.animateColorAsState(if (selected) c.accent else c.secondary, tween(220), label = "fg")
    Row(
        Modifier.pressable(onClick).clip(CircleShape).background(bg).padding(horizontal = 22.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, null, tint = fg, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(8.dp))
        Text(label, color = fg, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
    }
}
