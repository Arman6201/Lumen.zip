package com.lumen.gallery

import android.app.Application
import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter

const val VIDEOS_ID = -1L

data class MediaItem(
    val id: Long,
    val uri: Uri,
    val isVideo: Boolean,
    val takenAt: Long,
    val durationMs: Long,
    val bucketId: Long,
    val bucket: String,
)

data class Album(val id: Long, val name: String, val items: List<MediaItem>)

class GalleryViewModel(app: Application) : AndroidViewModel(app) {
    private val _media = MutableStateFlow<List<MediaItem>>(emptyList())
    val media: StateFlow<List<MediaItem>> = _media.asStateFlow()

    fun refresh() {
        viewModelScope.launch(Dispatchers.IO) { _media.value = queryMedia(getApplication()) }
    }
}

private fun queryMedia(ctx: Context): List<MediaItem> {
    val out = ArrayList<MediaItem>()
    val projection = arrayOf(
        MediaStore.Files.FileColumns._ID,
        MediaStore.Files.FileColumns.MEDIA_TYPE,
        MediaStore.MediaColumns.DATE_TAKEN,
        MediaStore.MediaColumns.DATE_ADDED,
        MediaStore.MediaColumns.DURATION,
        MediaStore.MediaColumns.BUCKET_ID,
        MediaStore.MediaColumns.BUCKET_DISPLAY_NAME,
    )
    val type = MediaStore.Files.FileColumns.MEDIA_TYPE
    val selection = "$type IN (?, ?)"
    val args = arrayOf(
        MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE.toString(),
        MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO.toString(),
    )
    ctx.contentResolver.query(
        MediaStore.Files.getContentUri("external"), projection, selection, args, null,
    )?.use { c ->
        val iId = c.getColumnIndexOrThrow(projection[0])
        val iType = c.getColumnIndexOrThrow(projection[1])
        val iTaken = c.getColumnIndexOrThrow(projection[2])
        val iAdded = c.getColumnIndexOrThrow(projection[3])
        val iDur = c.getColumnIndexOrThrow(projection[4])
        val iBucket = c.getColumnIndexOrThrow(projection[5])
        val iName = c.getColumnIndexOrThrow(projection[6])
        while (c.moveToNext()) {
            val id = c.getLong(iId)
            val video = c.getInt(iType) == MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO
            val base = if (video) MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            else MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            val taken = c.getLong(iTaken).takeIf { it > 0 } ?: (c.getLong(iAdded) * 1000)
            out += MediaItem(
                id = id,
                uri = ContentUris.withAppendedId(base, id),
                isVideo = video,
                takenAt = taken,
                durationMs = c.getLong(iDur),
                bucketId = c.getLong(iBucket),
                bucket = c.getString(iName) ?: "Other",
            )
        }
    }
    out.sortByDescending { it.takenAt }
    return out
}

fun buildAlbums(media: List<MediaItem>): List<Album> {
    val real = media.groupBy { it.bucketId }
        .map { (id, l) -> Album(id, l.first().bucket, l) }
        .sortedWith(compareBy<Album>({ it.name != "Camera" }, { -it.items.first().takenAt }))
    val videos = media.filter { it.isVideo }
    return real + if (videos.isNotEmpty()) listOf(Album(VIDEOS_ID, "Videos", videos)) else emptyList()
}

fun dayLabel(ms: Long): String {
    val zone = ZoneId.systemDefault()
    val today = LocalDate.now(zone)
    val d = Instant.ofEpochMilli(ms).atZone(zone).toLocalDate()
    return when {
        d == today -> "Today"
        d == today.minusDays(1) -> "Yesterday"
        d.year == today.year -> d.format(DateTimeFormatter.ofPattern("EEE, d MMM"))
        else -> d.format(DateTimeFormatter.ofPattern("d MMM yyyy"))
    }
}

fun timeLabel(ms: Long): String =
    Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault())
        .format(DateTimeFormatter.ofPattern("h:mm a"))

fun durationLabel(ms: Long): String {
    val s = ms / 1000
    return "%d:%02d".format(s / 60, s % 60)
}
