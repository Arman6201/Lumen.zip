package com.lumen.gallery

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.provider.MediaStore
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import kotlin.math.abs

@Composable
fun Viewer(
    items: List<MediaItem>,
    startIndex: Int,
    onClose: () -> Unit,
    onDeleted: () -> Unit,
) {
    val c = LocalLumen.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val pager = rememberPagerState(initialPage = startIndex.coerceIn(0, items.lastIndex)) { items.size }
    var chrome by remember { mutableStateOf(true) }
    var dragY by remember { mutableFloatStateOf(0f) }

    // Apple Photos behaviour: white/black chrome mode, goes pure black when UI is hidden.
    val bg by animateColorAsState(if (chrome) c.bg else Color.Black, tween(220), label = "bg")
    val progress = (abs(dragY) / 900f).coerceIn(0f, 1f)

    BackHandler(onBack = onClose)

    val deleteLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) {
        if (it.resultCode == Activity.RESULT_OK) onDeleted()
    }

    val current = items[pager.currentPage.coerceIn(0, items.lastIndex)]

    Box(
        Modifier
            .fillMaxSize()
            .background(bg.copy(alpha = 1f - progress))
            .pointerInput(Unit) {
                detectVerticalDragGestures(
                    onDragEnd = {
                        if (abs(dragY) > 260f) onClose()
                        else scope.launch { animate(dragY, 0f) { v, _ -> dragY = v } }
                    },
                    onDragCancel = { scope.launch { animate(dragY, 0f) { v, _ -> dragY = v } } },
                    onVerticalDrag = { change, dy -> change.consume(); dragY += dy },
                )
            },
    ) {
        HorizontalPager(
            state = pager,
            pageSpacing = 16.dp,
            beyondViewportPageCount = 1,
            modifier = Modifier.fillMaxSize().graphicsLayer {
                translationY = dragY
                val s = 1f - progress * 0.25f
                scaleX = s; scaleY = s
            },
        ) { page ->
            ZoomPage(
                item = items[page],
                isCurrent = page == pager.currentPage,
                onTap = { chrome = !chrome },
            )
        }

        // Top bar
        AnimatedVisibility(
            visible = chrome && dragY == 0f,
            modifier = Modifier.align(Alignment.TopCenter),
            enter = fadeIn(tween(180)) + slideInVertically(tween(220)) { -it / 3 },
            exit = fadeOut(tween(140)) + slideOutVertically(tween(180)) { -it / 3 },
        ) {
            Box(Modifier.fillMaxWidth().background(c.bar).statusBarsPadding().padding(horizontal = 4.dp, vertical = 4.dp)) {
                IconBtn(Icons.Rounded.ArrowBackIosNew, c.accent, Modifier.align(Alignment.CenterStart), onClose)
                Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(dayLabel(current.takenAt), color = c.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                    Text(timeLabel(current.takenAt), color = c.secondary, fontSize = 12.sp)
                }
            }
        }

        // Bottom bar
        AnimatedVisibility(
            visible = chrome && dragY == 0f,
            modifier = Modifier.align(Alignment.BottomCenter),
            enter = fadeIn(tween(180)) + slideInVertically(tween(220)) { it / 3 },
            exit = fadeOut(tween(140)) + slideOutVertically(tween(180)) { it / 3 },
        ) {
            Row(
                Modifier.fillMaxWidth().background(c.bar).navigationBarsPadding().padding(vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
            ) {
                IconBtn(Icons.Rounded.IosShare, c.accent) { share(ctx, current) }
                IconBtn(Icons.Rounded.Tune, c.accent) { edit(ctx, current) }
                IconBtn(Icons.Rounded.DeleteOutline, c.danger) {
                    val sender = MediaStore.createDeleteRequest(ctx.contentResolver, listOf(current.uri)).intentSender
                    deleteLauncher.launch(IntentSenderRequest.Builder(sender).build())
                }
            }
        }
    }
}

@Composable
private fun IconBtn(icon: ImageVector, tint: Color, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(modifier.size(48.dp).pressable(onClick), contentAlignment = Alignment.Center) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(24.dp))
    }
}

private fun clampOffset(o: Offset, s: Float, size: IntSize): Offset {
    val mx = size.width * (s - 1f) / 2f
    val my = size.height * (s - 1f) / 2f
    return Offset(o.x.coerceIn(-mx, mx), o.y.coerceIn(-my, my))
}

@Composable
private fun ZoomPage(
    item: MediaItem,
    isCurrent: Boolean,
    onTap: () -> Unit,
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }
    var size by remember { mutableStateOf(IntSize.Zero) }

    LaunchedEffect(isCurrent) { if (!isCurrent) { scale = 1f; offset = Offset.Zero } }

    fun zoomTo(target: Float, focus: Offset) {
        val fromS = scale
        val fromO = offset
        val center = Offset(size.width / 2f, size.height / 2f)
        val toO = if (target > 1f) clampOffset((center - focus) * (target - 1f), target, size) else Offset.Zero
        scope.launch {
            animate(0f, 1f, animationSpec = tween(280, easing = FastOutSlowInEasing)) { t, _ ->
                scale = fromS + (target - fromS) * t
                offset = fromO + (toO - fromO) * t
            }
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .onSizeChanged { size = it }
            .pointerInput(Unit) {
                detectTapGestures(
                    onTap = { onTap() },
                    onDoubleTap = { p -> if (scale > 1.01f) zoomTo(1f, p) else zoomTo(2.5f, p) },
                )
            }
            .pointerInput(Unit) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false)
                    do {
                        val ev = awaitPointerEvent()
                        val zoom = ev.calculateZoom()
                        val pan = ev.calculatePan()
                        // Only take over the gesture when pinching or already zoomed in;
                        // otherwise let the pager swipe and the drag-to-dismiss work.
                        if (ev.changes.size > 1 || scale > 1f) {
                            val ns = (scale * zoom).coerceIn(1f, 6f)
                            offset = if (ns > 1f) clampOffset(offset + pan, ns, size) else Offset.Zero
                            scale = ns
                            ev.changes.forEach { if (it.positionChanged()) it.consume() }
                        }
                    } while (ev.changes.any { it.pressed })
                }
            },
        contentAlignment = Alignment.Center,
    ) {
        val imgMod = Modifier.fillMaxSize()
            .graphicsLayer {
                scaleX = scale; scaleY = scale
                translationX = offset.x; translationY = offset.y
            }
        Pic(item, imgMod, ContentScale.Fit)

        if (item.isVideo) {
            Box(
                Modifier.size(72.dp).pressable { play(ctx, item) }
                    .clip(CircleShape).background(Color.Black.copy(alpha = 0.45f)),
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.Rounded.PlayArrow, null, tint = Color.White, modifier = Modifier.size(40.dp))
            }
        }
    }
}

// ───────────────────────── Intents ─────────────────────────

private fun mime(ctx: Context, item: MediaItem) =
    ctx.contentResolver.getType(item.uri) ?: if (item.isVideo) "video/*" else "image/*"

private fun share(ctx: Context, item: MediaItem) {
    val i = Intent(Intent.ACTION_SEND).apply {
        type = mime(ctx, item)
        putExtra(Intent.EXTRA_STREAM, item.uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    ctx.startActivity(Intent.createChooser(i, null))
}

private fun edit(ctx: Context, item: MediaItem) {
    val i = Intent(Intent.ACTION_EDIT).apply {
        setDataAndType(item.uri, mime(ctx, item))
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
    }
    try { ctx.startActivity(Intent.createChooser(i, "Edit with")) } catch (_: ActivityNotFoundException) {}
}

private fun play(ctx: Context, item: MediaItem) {
    val i = Intent(Intent.ACTION_VIEW).apply {
        setDataAndType(item.uri, mime(ctx, item))
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    try { ctx.startActivity(i) } catch (_: ActivityNotFoundException) {}
}
