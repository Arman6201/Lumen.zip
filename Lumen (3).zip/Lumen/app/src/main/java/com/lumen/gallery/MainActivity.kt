package com.lumen.gallery

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    private val vm: GalleryViewModel by viewModels()

    private fun perms() =
        if (Build.VERSION.SDK_INT >= 33)
            arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO)
        else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)

    private fun hasPerms() = perms().all {
        ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            LumenTheme {
                var granted by remember { mutableStateOf(hasPerms()) }
                val launcher = rememberLauncherForActivityResult(
                    ActivityResultContracts.RequestMultiplePermissions()
                ) { res ->
                    granted = res.values.all { it }
                    if (granted) vm.refresh()
                }
                LaunchedEffect(Unit) { if (!granted) launcher.launch(perms()) }
                if (granted) LumenApp(vm) else PermissionScreen { launcher.launch(perms()) }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (hasPerms()) vm.refresh()
    }
}

@Composable
private fun PermissionScreen(onGrant: () -> Unit) {
    val c = LocalLumen.current
    Column(
        Modifier.fillMaxSize().background(c.bg).padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text("Lumen", fontSize = 34.sp, fontWeight = FontWeight.Bold, color = c.text)
        Spacer(Modifier.height(8.dp))
        Text("Allow access to your photos and videos to get started.", color = c.secondary, fontSize = 16.sp)
        Spacer(Modifier.height(24.dp))
        Text(
            "Allow access",
            color = androidx.compose.ui.graphics.Color.White,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.pressable(onGrant).clip(CircleShape).background(c.accent)
                .padding(horizontal = 28.dp, vertical = 14.dp),
        )
    }
}
